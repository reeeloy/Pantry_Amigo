<?php

namespace MercadoPago\Resources\Payment;

/** Metadata class. */
class Metadata
{
    /** Order number. */
    public ?string $order_number;
}
