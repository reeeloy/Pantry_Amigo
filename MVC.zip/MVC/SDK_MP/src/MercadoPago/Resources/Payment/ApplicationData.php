<?php

namespace MercadoPago\Resources\Payment;

/** ApplicationData class. */
class ApplicationData
{
    /** Name. */
    public ?string $name;

    /** Version. */
    public ?string $version;
}
