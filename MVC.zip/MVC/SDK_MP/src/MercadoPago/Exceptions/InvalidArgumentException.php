<?php

namespace MercadoPago\Exceptions;

use Exception;

/** InvalidArgumentException class. */
class InvalidArgumentException extends Exception
{
}
