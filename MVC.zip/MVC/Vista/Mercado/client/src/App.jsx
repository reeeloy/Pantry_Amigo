
import Product from "./Components/Product/Product"
function App() {


  return (
    <div>
      <Product />
    </div>
  );
}

export default App
