import express from 'express';
import cors from 'cors';

//SDK mercadopago
import { MercadoPagoConfig, Preference } from 'mercadopago';

const client = new MercadoPagoConfig({
    accessToken: "APP_USR-6712059526286166-061310-51a8fef48cbadfd8a66d91ac4e92b8fb-2378312331",
});

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
    res.send('este es el serveeeer de mercado pago');
});

app.post('/create_preference', async (req, res) => {
    try {
        const body = {
            items: [
                {
                    title: req.body.title,
                    quantity: Number(req.body.quantity),
                    unit_price: Number(req.body.price),
                    currency_id: 'COP',
                },
            ],
            "back_urls": {
                "success": "https://PantryAmigo.com/success",
                "failure": "http://www.tu-sitio/failure",
                "pending": "http://www.tu-sitio/pending"
            },
            "auto_return": "approved",
        };

        const preference = new Preference(client);
        const response = await preference.create({ body });

        res.json({
            id: response.id,
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            error: 'Error al crear la preferencia :(',
        });
    }
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});


