<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Error en la donación</title>
</head>
<body>
    <h1>❌ Lo sentimos, ha ocurrido un error al procesar el pago.</h1>
    <p>Intenta nuevamente más tarde.</p>
</body>
</html>
