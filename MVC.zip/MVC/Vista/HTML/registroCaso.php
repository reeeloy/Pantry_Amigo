<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pantry Amigo</title>
    <link rel="stylesheet" href="regCaso.css">
</head>
<body>
    <header>
        <nav>
            <a class="activo" href="#">INICIO</a>
            <a href="#">REGISTRARSE</a>
            <div class="logo">
                <img src="logo.png" alt="Logo">
                <h1>PANTRY AMIGO</h1>
                <p>DONANDO CON INSPIRACIÓN</p>
            </div>
            <a href="#">INICIAR SESION</a>
            <a href="#" class="help">?</a>
        </nav>
    </header>

    <main>
        <div class="container">
            <div class="card">
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPkAAACUCAMAAABm+38mAAABoVBMVEX////19fXs7OwRYWIZiY0aLjX6+vrh4eH/T1rv7+/HiHb/v5zy8vI4WmQWc3jl5eUAgISqy8wpjZFnqasWenwAUVMUbnC41dYAS00aIioZaW25y8sAAADk8fFVnaCx0NEAHSbE1teXsrSuwsJocHM4hYmntrdblJh2mJh3oqYAKzL/R1PW19fwUFv/V2IvbG4gNz//bWoAABHCfWciWmQAW2UAEh3/M0P1gon/PUsNJi7V4eL76LQbTFL9zR7900j/ur65vb6ipqhaZGiRVmCsfnKgVWDVqZzk1db/07/+7u9pWGJOWWP/o6j778z92W779ej94Iv/3+H/eYHDQEuMMT19P0eGYGW3i49fMzs6MDdnSU/tx8m8eoBGKjN1bnLQOkeFiYpuGSVjUU56XVcfEhU+SE1GKyS4Zl9KQ0Paw72HWU2Qc2eeZFPhUl3IXl7Cb1ewSVVng4jqaWjYfHDgrpLKrrHVkpiQFyYAPUv/sof2ua6dgX+4mYCAfHMAKj3fi2P/pIz/jFH+l2ffgooAESvOuHXj1KvDoiRgXSnFj2m83WMEAAAVLklEQVR4nO2djV/bRprHJYFHHpAZAjR7JEANMaHYwjHgGDCksWQIhuAEME0uWTddX3q+K5tzDrq0m1zbvdxm9273r7550cvo1TY24Gz5ffqhsi3L853nmXmeeZEiCNe61rWuda1rXeta17rWta51rdYFqEQRgKsuyaWKYVuHV1yay5Mb9teC7mPkXwW6v2//CtADEP/ByYEAxMDP/iHRafBSoMj0qRu95VgEKC6UsEQxGP5TIQdcPA4/j5IqFByKnDzf/QTIAacmZ1JqhXFjcCgqwey9Tw7c8j+H/CWgjJpIERFETrvjqrG/c2kE55GHOgBdESXKrVgGxybHL5EsQ97s+FPr2z1O3uKbuGFjcMaomOD4NT5GvNkVCMOv/elJUSzTYptDyF4SJ5AQfmkZXhE7sfnFxIPOripa6NDRpxMHgMT/qUewU877e61Fl3Yvit2Qc8T2v0+ALXK+UzPJSYUoEofeFkPL0aVdGZ3SudEBIRQDhDt5ReJkOHw7DM2DS/tFJrLj0DnRAXFqKEqK4gOuUHfyordc/taiS3sSJbfOhW64OqRQHnBcHxA5f4UkNa2W3j+udojuBcfo7V8VGHkqdOerXIhzCTf1K4xpwA/cwA8YXvldRQCGrb2ZOvH0gF8IGsBdtABtfYHgtGitXYgMRykxvhyEHl+3r4fc178S8mBjc2qhZKy9MS+Bfm2cVQqLapKzpmFrVdtdAT9QyIv0xmbJdgtYh77XoT0CV43eXp3msJD6PBSd6MoVGD2gt/TvPQuV9NFXz57/s5fdOMMi8YY0aNQGjWrQ3eavwuita7Kc/t2Ll8lk/uVvq66PjJoxHcgvkpt5LGsKUHR2LbCXRyzrX0cXXiYjWJnIK6fVTYsFebrV0slYlWCT/5RPxejom9+lXxHwfD6eWarxH5mlBkbH5Wdy0ZqaYa/c5MoVILUmUPuXhSNq8Nevvx0YmOC804pJonts5m7nHDt0x9GedXd96av0M2zyl28GiP5Vsj+yyixyk8sek3vCh+uNXnV3tR5/1XiW/G5ri4IP/BuyPrKLTE0ZQO5JlVgARFjNyXGGdFUuIdaWIsl/3/rG4MbkVkHtzB4Ek3vzVkSnZ1jjp+zBwyM2dX1FPqHG8/nvtpYHtpcN8qLt4tZJweRecDIXSftC2+t9fpamEtZVLgPULbEYj2DygWN5gKH/XrMLZ5eT9dlkFNDM1elMpDFFZwZ2788C51UuZP4pXMTXcTR7s41QiaG/tsrJWQKYc2+KO675joeMNM4c2CEnlMPaPP6lUQuCVkvkSTiLv9mWZVQ6xuz/ofnNmYpmrPakMr7kRu5OvQQfId6b/akv2em1ej5OwPOZLUyuynLpePuNbJfRPtNycs8A1Q/cIIdmZTlymWDuyyIHUKtn6plMMhmJ4/xFpuhI40zOkUOKoXhH5gEzEqSPM04lRr+ywOUjoE+Mx7CyjcaLZBKnMNsSQZd01T7FTe47GUPf8zG6oz300kKyOpGJUfIo1lscy5eXVZx4aDU7jREc5NiEBpWnnSs+rZ3zDmz0HlpgAnqcgT83yQcG/nNbT+RqfIduHzqc2mV0JaC5cw2jh9bWlMQDSn6/YZMPvFyK52pcZ8RVgoPML6Pxae+wJ8nldxQ8tkfAo4/oUGULD1riCb/hintiy69b9qKLPUmuGyY/YeRFbPSt4gNMXpS5s7gcLrD/shRictA75FKWtfLYAiPPFr95U7z/6FXSSc65eyBVkNH5+NdD5LVvY4T9/qOoQU5ebEZPkrmaY1xll9fN5Z1yd3YFeLSicOS9Ai6MY98mtLR/i6Y38XF2byHayOQ0x3ncMNXbgbnZ+chGxir2571j8unfk2adNU2+8DzLHL8R011FtJMvD7nH5aHjI25M20POrtFBWYKFNIOctPiTU88cgoUenqe5Grrzox5y9mM2BfE2zcgbz7NZUgkLm6ey51wT3cfdWyXvnV2QgE1BfB811HjMolsje6r6nG0U22P0kMEL3Stlft5DJmfzTn9IW+R7j+jx0f2Y5nc+Y/cY3XeRyWrmtuF7xuKCOOA0ebTxiIV13MXf9f8KLbzb6MHkCtspZfVvvSLWym2TRxcY+AIOcwHkbDt3q+TGIovx+WWihQtsM/KFqEsn92MPAsmJxBbJySE0V1zPY/ILmo7cNSaXPeixbPFNKfSrMJzc3A1qDV3PAX5R2+GITPKBZSf6ZmJra+A4vFgcus/GMMWuEevDNgt3AfvhOG2b6ANG+6Z/F+kYPZyc83ff4Zp3ubWdcl3ApjCXSgMudArO6qMJuY0est7STfCukgNzSYFHXzk8Ju8tNyO30P3X0V110kMBTSDgCEnWGtpAmjr7WhmUWiNn6GGrqn7gvlUg1vJ17RLzu/JapVpCJauxk4QmVdkVdin5dvP9DWKQxYnRoWPakYisqAAf1wdaLpfJ5JbqPgnzhagaXUutpMulkjFqGdguRFPpKgZibnDcvG0CGEjOybgbmbO8fQRVVa3lMpF8PhLJJZDPb3RfoLpaSadSa6nV6g80sm0jVEiXSZkY+fJ2qSk78N3q7A/OO7P5StQnJibimUj89bevMb7vWKHrgmi9VFitYMOvVT7+AZPKSJardDeU0faXB7bD0xmisFVBym2Au9qOgQ4T8Ugmkx9/czZ49k0+p19GggswJ2atFlYX19ZS6e8HSvQNMq0m4Ka/vMzYj0tNm3sYuxmL3OCCcfOqHMHg8e+2BrHO6rm9y3D3w4I8iVkRKmH49Frqe1WSDUFBKR0b8MslWVKaBdMgdvtr9r5P5yolTOTyudc/D1K9ybzZufj+XSynK6uFEpKI4TF8JbVYIDVBRcwh7lLLH9PaQaiJ5X02APC1xd2drFltmb6nFos/nTFw7O9n73e6i+mj3cVUKppeqJRLkxIilv/hx8aP06Yw6iSuB1X7Ab9QqdYnkaH1oGuaGyC8LsLVm27vLqToEO4Mmjo7ez/YXUwf7aZIvobho+lyVYafT/WPzM72mxoxhY/Hbg25NNv2r9kml2K6+91dixzXQQf3UoUWwHbF0h8b5nxEaiX1tQ3t0VifB32szd81fEBRVeE0dqppRj9m1odp9B1Z3rkgb+dG1PpSMvnipLFA8d+GgGPyvls33VZvryMyENFpIvYgFnvwzjC7eZEdC1zeeX8xcY0jx3E0ksR6hulDwQl5X58L/dac3762QBk0sHZ6ShfxjKZudgfU3Xd2Sd+6M3gxRufI9+hGKEpfvzc2NhQMT8mpxzP8mzdnv5ibm2nH6sBM2JzkVha7Q+3NyN8LYPeQaPdCyKEU4ZSJRF7da0LO6bPP292hahpXT7BdCqeuT3YpONmVhB3/v8qrlbdHR41V930FnZOTezDQUsSh/K3Wyf/ptlFo98xB8EyC4e6qrtdqp4niXQvbOAtZJh88W1hJPdrLZh+fRAtdJYdse6U84SQfb5Nc8ZNzPpa/c8O6FRmI0rqqiuYrq2AyTaVJV/cT7nCzZEE3+2il3LWMjpJTc2g8ed0kn3IyD09NBZH7bnc0LceEfIzuEL8BiaAfD74fHPx5M5revG/s4kiVu0+uc96+h/t5Qj48d2ds1qEb88PdIvdaz9EccJmUHQx+dq8RXdhjG3di2Ua60HXyWs7u32oG+axIn5ZgCypwrBVyiNgm7hBywZObeR80tI8tXoyxBR5G/pjMEHWZvBi3fV0zyb1fACHkiGwEMTZlg6bkgisB8AkO4vYvsewmRx7LHnXL301yBdQt8nxdLZ6HHCoi1483Jxcc96r5PFrqMH1yn27Ks8ljj1OLvrdKnptcBLazR2qII+dpQLjNHacqzckFex4O+Ey/766uNR6THTp2O8d6u9Ydo1vk0O7a85psezvSVEMaPoKtkdMrtkBOHslB9g6IvssO8gsczmJkuw5P/rxLRrfIuXA+Lqk2uaRa5KoqNyWnY3HytIkWyQVHEHdKr2NHP6E7VR5ns9mssTHzaK3QTXKgWuT5PYEjB9TaRPhAAqHkCgD0cQUiQhIArZIHCSSyxvasaPrRL7/8kkgkqOkfpSrdMLpFrlnhPKcDle/bkWV14pLh5Iosk1tukYzEjsnFd9nH5vrWIpmdOTv7iQa2RleMbpJzicyErDjImcNrqlHuEHJIyCWkICR3webqu1iM7E1KM3Kin6m/n6RWuxDTLXIrkclngOQkF0QJu685cRaSveIrYVQJQFlWOifXH8Syzxe85KQNdMHdJbpLFZObo/NIruYhdygsbxcJNMTdJbE57JCcDtzfWt5O9BO732BhpdAdcglBbow6oSkcuTvawCbkIjG3SNu50iE5GbdnNxd48l8M8m6ksEaeDWpWBpfDCCb52N2Z+0Njw7aG1LkmNkfIjOpiZ+TSn2gYO6IzogZ57T4jj650jVyxgnmuJtrk7kGq8UYIOacOyYX/Xn5TjN3/GjfzxQ9ktIr1/SbZdv82mupC787ART1iOztn83ZmJuiTdBwzMG2SK4pzlPo/f8Y6K334YE2+D+JaaBw10pWC3Plqm0FeNPu3fAZ1hdy857R1chGpJBkQzQec72Dy9+8HHYqmoouVcglHTbmjuRlgPtZIUesm+ZJO+jz5nORs2zp5LJjEbi5vmZz0s+QUFSGIaGjcGTwbdOnD4mq5KpOb9kvVjiYjrV26Yo0boJK4LBfPR+55OlKr5AAnxsaD1ES4Q+ZdcXiQXeA7hSpi2IXVxZVukGNQK5jr9A21/u5BhpIPu0Te6B/iqe9h9U23PxvlLApJAOioXpbkbXuq3QFewvWKSoXy6mJqLdpRSDfJRT3jMLkEp4fGxoaGfc196+bNmzz4Z1+sY4nkVmyPyHMvmQxy9iw8YO8YoQ9+JscKMnpFlaupksm8s1MqEWNjarKdJRWNrq10Mko3yKFkBfOlGqKmm/al9nX0z+4Kk4R9fdqr26buYHSc+8s4CcY9GWJLCAgKEjsmQztzDgvx6DuDO/v7+4C0oVK1XFlMRwl1amUl+rHafNdKU3JFM/s3bHKF9sm32yGfnB/x1z1Ls+RJsJD2f+wJLPS+LkVgh+TYmsMSZQMdm/h451DTdV3TfvhYSVvrvKnVUum4qk52sNDIxhQI6KbJccrO0u2ZtsinAs62WsVnp80LY5aJ7FNCsnq88wFH861Mnmp8fPzlqxfPvjo5efvxY7laKBcqa+UO3J09vxCiRNwyucDmz76gLFMjHMZoCLk/+IhFfrN/NFxzTs0cD/6Z5DHf/iXCK0kVT46/enZEtjicf8BGbQ4EzTR5vGbcnIBOKaR6w15hGFXGWiMf7h8ZNVzmpgXuCREu9fU5V6TnJ0V0iNZzkQDhCvgqHT2/0Rm5Yo7MmckxOZRjBGFGlrglBrQ+FkI+PDU8MjI7NTU3P3N73WwtNy3wcA2P9Lk2YdyaW8cdgG5MkGUyfvCvopUOya38LV9jM8wSRA8oubX+Sf+HhkLIZ+WZO6odr+9w5M3B+zG5B31agdQkGSo/9BeNc7s7YD37hN2x08EWTmSSIza5pCLyDFSwHkY+Z1zRqKzbNnkL4JTcjT47zY2cfc2e3+yIHCJzVSlfA+T5PoRc48gFtaarTcnHrJVycl1h2mrnrYD39/f5onMrfX7o8cR5wRm5Zl0eARxEsXlxA+PJtZoqtURObS6sk2cCrY8Y5K2B95tdoaEh0qcOzZ069jJ40DsklxIGebxGH62Px5m4gb2zyfcPnj4RmpIP48rB2RepKO2uJLAQT8iHKAqP6hoH8OSmZtZZVhjPh6Kffxs0WRaQrcRVIcMLMpUkwoRN/uTpw4cPN5qTqwLSNTIhr+L/SdLocD+XyfQ1s7z7kqx4ipYLQY8Xzw1OyBVzmj2HO3aTXNl7YJNj8IcH+03JfyOomq7hylNlSYXiTIfkdHJDAVokF4SerHeWvYrmxSZI18bIgRThyZ/uCxvNyWcETVXU27pWI4/DBF0gJw98F+Sif1tPJl8Uzg+Oi2iFtCWSvikybedAmnCSg+bk/fMChALSwLQARFkQbviRD899wWl+fjaUnIZcQdAzPujjL45S5Q6mX4EE9sxmTgKXSGeBcBw7B/msoOBWriqCJgDZSGXc5LOuLdFfhJJDiTi87urXMpmXR3jUtlrpaModD1YmkszkOu6WAXn0sogHylp75OuMXMTjbwKvKrIkTI/4k/NTs03J8SUTS3l3KM8Ya23pDlaYRLj+1YtIkqRvpH0r2l1VJGGptsSRf/l04wkjD8jbdZWQjygkqmGbI1VTZYHWhg+5aPwrFfRR1k3IFagbHZyDPfnMGKh3MAeJqzXVOHkWSU7oBFKp1Qi5rhfjPDnWU5t8yAVujdUQwDaXcQWqSBKDyc3pKZwyNSFXqMEjbvTky6OFhVS6kkoVOiAXy2vR6MLR8xoiP7X/1//Fb+7/daP4F5t8/2Bj44DG88mwsVp//7RgrLHQ7B2SbXN+5KhlcrW+ZHHbg5bkb/HQfLVQPUxFy+cPawCmyRzPQpUuEGw8JYH7ycHDh//3Ny6Hs1plOPnwHece1yBya1YWe/vocAi5UJvguE2zJ79rsJsmhcJKJ4vohbVKJZpaVWihD758eLCxv/Hwy4ONv28SlhnHE5dhE5vP8P82DkQB5I66DCfP5F2Ojo+Smxh8sZIm6N930sVVVrDN0wWgkInADdKcFUz+BJTf0oKq6vz8jKE7aL4/lHyeepG0rt2Yn5qaGg1o5w7NBJKTfxujbhic79aTf0zhTp3caAOE3Q66uN1CZW0F27xEO1tKDjH5vlBukOIMj9pGGR79fDicfE6dmRuZ5WfufDKZuTmcwFgKzGRmcHEEmmrw5PGlpYRWXSPdOs1iDjuZjaoWVqNrawydJ//ISsrPqRrHgeQjo54p2Jaz1xE3OdlhxkYUJnk+ntvTydpSCbfz1UNjmeL85BI8rK4uMvQD09stcj+1MffaGbkkTVjru/l8pF5T2ZojNvpqtdOn3dPUGJaq5XQBHzz98umTfXiA2/k+83Zf+cbzZvPt7Y5YKLmoj8fJXHs8Ut+rachcoltdqRSa3xjbjJw9ohXCwzI2+gEZjz7ZIH/f/9gfsGwyMnbPpb67k6MB5w5ZJwVdzZSrNu/SlRegF+v1+l5CV+kmFEO4R95tdmNoc3LrJr1dRRT3NzY2ntC/G4elG59T3bnzuUs37ri1Lk7/xl/WstrtG01013HFu0b0E6CmaeT5ZMC6xRUcrhV2r+5p9lepQieD009a1V8reO88TO5a1+od/T8ZmWlV32bW5QAAAABJRU5ErkJggg==" alt="Donación">
                <div>
                    <h3>CASO-XXXXX</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique, a fuga nisi magnam suscipit commodi iste dolorem reprehenderit sunt temporibus molestiae voluptate aspernatur quisquam! Assumenda.
                        <br>
                    </p>
                </div>
            </div>
            <div class="formulario">
                <form action="entrega.php" method="POST">
                    <h2>REGISTRO</h2>
                    <input type="text" name="nombre" placeholder="NOMBRE" required>
                    <input type="email" name="correo" placeholder="CORREO" required>
                    <input type="text" name="direccion" placeholder="DIRECCION" required>
                    <input type="number" name="cantidad" placeholder="CANTIDAD" required>
                    <button type="submit">ACEPTAR</button>
                </form>
            </div>
        </div>

        

    </main>
</body>
</html>
