<?php

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Mostrar alerta en JavaScript
    echo "<script>alert('Entrega finalizada'); window.location.href='index.html';</script>";
}
?>